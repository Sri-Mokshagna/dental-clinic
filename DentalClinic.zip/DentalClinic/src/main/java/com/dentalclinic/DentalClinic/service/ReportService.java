package com.dentalclinic.DentalClinic.service;


import java.util.List;

import com.dentalclinic.DentalClinic.model.Patient;
import com.dentalclinic.DentalClinic.model.Report;

public interface ReportService {
    Report save(Report report);
    List<Report> findByPatient(Patient patient);
}
