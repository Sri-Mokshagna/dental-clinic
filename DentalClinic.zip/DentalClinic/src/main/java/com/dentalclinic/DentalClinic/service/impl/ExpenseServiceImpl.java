package com.dentalclinic.DentalClinic.service.impl;

import org.springframework.stereotype.Service;

import com.dentalclinic.DentalClinic.model.Expense;
import com.dentalclinic.DentalClinic.model.User;
import com.dentalclinic.DentalClinic.repository.ExpenseRepository;
import com.dentalclinic.DentalClinic.service.ExpenseService;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.List;

@Service
public class ExpenseServiceImpl implements ExpenseService {

    private final ExpenseRepository expenseRepository;

    public ExpenseServiceImpl(ExpenseRepository expenseRepository) {
        this.expenseRepository = expenseRepository;
    }

    @Override
    public Expense save(Expense expense) {
        expense.setDate(LocalDate.now());
        expense.setApproved(false);
        return expenseRepository.save(expense);
    }

    @Override
    public List<Expense> findByUser(User user) {
        return expenseRepository.findByAddedBy(user);
    }

    @Override
    public List<Expense> findPendingApproval() {
        return expenseRepository.findByApproved(false);
    }

    @Override
    public List<Expense> findByDateRange(LocalDate start, LocalDate end) {
        return expenseRepository.findByDateBetween(start, end);
    }

    @Override
    public void approveExpense(Long id) {
        Expense expense = expenseRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Expense not found"));
        expense.setApproved(true);
        expenseRepository.save(expense);
    }
    @Override
    public void deleteById(Long id) {
        expenseRepository.deleteById(id);
    }


    @Override
    public List<Expense> findByAddedBy(User staff) {
        return expenseRepository.findByAddedBy(staff);
    }

}
