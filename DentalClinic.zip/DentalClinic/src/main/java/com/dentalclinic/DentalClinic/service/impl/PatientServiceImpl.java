package com.dentalclinic.DentalClinic.service.impl;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.dentalclinic.DentalClinic.model.Patient;
import com.dentalclinic.DentalClinic.model.User;
import com.dentalclinic.DentalClinic.repository.PatientRepository;
import com.dentalclinic.DentalClinic.service.PatientService;

import java.util.List;
import java.util.Optional;

@Service
public class PatientServiceImpl implements PatientService {
	@Autowired
    private final PatientRepository patientRepository;

    public PatientServiceImpl(PatientRepository patientRepository) {
        this.patientRepository = patientRepository;
    }
    @Override
    public Optional<Patient> findByUsername(String username) {
        return patientRepository.findByUserUsername(username);
    }


 

    @Override
    public Patient save(Patient patient) {
        return patientRepository.save(patient);
    }

    @Override
    public List<Patient> findByDoctor(User doctor) {
        return patientRepository.findByDoctor(doctor);
    }

    @Override
    public List<Patient> findAll() {
        return patientRepository.findAll();
    }

    @Override
    public Optional<Patient> findById(Long id) {
        return patientRepository.findById(id);
    }
	@Override
	public void updatePatientInfo(Long id, String medicalInfo, double treatmentAmount) {
		// TODO Auto-generated method stub
		
	}

	
}
