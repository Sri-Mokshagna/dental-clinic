package com.dentalclinic.DentalClinic.service.impl;

import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

import com.dentalclinic.DentalClinic.model.Patient;
import com.dentalclinic.DentalClinic.model.Role;
import com.dentalclinic.DentalClinic.model.User;
import com.dentalclinic.DentalClinic.repository.PatientRepository;
import com.dentalclinic.DentalClinic.repository.UserRepository;
import com.dentalclinic.DentalClinic.service.UserService;

import java.util.List;
import java.util.Optional;

@Service
public class UserServiceImpl implements UserService {

    private final UserRepository userRepository;
    private final PasswordEncoder passwordEncoder;
    private final PatientRepository patientRepository;

    public UserServiceImpl(UserRepository userRepository,
                           PasswordEncoder passwordEncoder,PatientRepository patientRepository) {
        this.userRepository = userRepository;
        this.passwordEncoder = passwordEncoder;
        this.patientRepository = patientRepository;
    }

    @Override
    public User save(User user) {
        if (user.getRole() == null) {
            user.setRole(Role.PATIENT); // default role
        }
        if (user.getPassword() != null && !user.getPassword().isBlank()) {
            user.setPassword(passwordEncoder.encode(user.getPassword()));
        }
        return userRepository.save(user);
    }



    @Override
    public Optional<User> findByUsername(String username) {
    	
        return userRepository.findByUsername(username);
    }

    @Override
    public Optional<User> findByEmail(String email) {
        return userRepository.findByEmail(email);
    }

    @Override
    public List<User> findByRole(Role role) {
        return userRepository.findByRole(role);
    }

    @Override
    public List<User> findAll() {
        return userRepository.findAll();
    }

    @Override
    public void deleteById(Long id) {
        userRepository.deleteById(id);
    }
    @Override
    public void assignPatientToDoctor(User patient, User doctor) {
        patient.setRole(Role.PATIENT);
        // maybe set doctor_id column (add in User entity if needed)
        userRepository.save(patient);
    }

    @Override
    public void updatePatientInfo(Long id, String medicalInfo, double treatmentAmount) {
        Patient patient = patientRepository.findById(id).orElseThrow();
        patient.setMedicalInfo(medicalInfo);
        patient.setTreatmentAmount(treatmentAmount);
        patientRepository.save(patient);
    }

	@Override
	public List<User> findDoctors() {
		// TODO Auto-generated method stub
		return userRepository.findByRole(Role.DOCTOR);
	}

	@Override
	public Optional<User> findById(Long id) {
		// TODO Auto-generated method stub
		return userRepository.findById(id);
	}

	


}
