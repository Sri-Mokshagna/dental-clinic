package com.dentalclinic.DentalClinic.util;


import com.twilio.Twilio;
import com.twilio.rest.api.v2010.account.Message;
import com.twilio.type.PhoneNumber;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

@Component
public class WhatsAppSender {

    @Value("${twilio.account.sid}")
    private String accountSid;

    @Value("${twilio.auth.token}")
    private String authToken;

    @Value("${twilio.whatsapp.from}")
    private String fromWhatsApp;

    /**
     * Sends a WhatsApp message to a given phone number.
     * @param toPhoneNumber The recipient's phone number in E.164 format (e.g., +919876543210).
     * @param messageBody The text message content.
     */
    public void sendMessage(String toPhoneNumber, String messageBody) {
        try {
            Twilio.init(accountSid, authToken);

            Message message = Message.creator(
                    new PhoneNumber("whatsapp:" + toPhoneNumber),
                    new PhoneNumber(fromWhatsApp),
                    messageBody
            ).create();

            System.out.println("✅ WhatsApp message sent! SID: " + message.getSid());

        } catch (Exception e) {
            System.err.println("❌ Error sending WhatsApp message: " + e.getMessage());
        }
    }
}
